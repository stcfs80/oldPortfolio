$(function(){
    $("#top_navi #mainnav li").mouseon(){
        $(this).find(".subnav").slideDown("slow");
    }
})